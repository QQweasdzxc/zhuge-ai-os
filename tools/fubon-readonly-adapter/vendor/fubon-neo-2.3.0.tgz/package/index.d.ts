export * from './trade.js';
import { CoreSdk } from './trade.js';
import { RestClient, WebSocketClient } from '@fugle/marketdata';
import type { WebSocketVersionOption } from '@fugle/marketdata';
import { Mode } from './adapter.js';
import type { FutOptOrderResult, OrderResult } from './trade.js';
export { Mode };
export type { WebSocketVersionOption, WebSocketVersionMap, WebSocketFutOptTrade, WebSocketFutOptTradesData, WebSocketFutOptBooksData, WebSocketFutOptAggregatesData, WebSocketFutOptMessage, } from '@fugle/marketdata';
declare class FubonSDK extends CoreSdk {
    marketdata: {
        webSocketClient: WebSocketClient;
        restClient: RestClient;
    };
    /**
     * constructor of FubonSDK
     * @param pongInteval
     * @param missedCount
     * @param url The first value
     */
    constructor(pongInteval?: number | null, missedCount?: number | null, url?: string | null);
    /**
     * Initial market data and get authorised
     * @param mode - Speed or Normal mode (defaults to Speed)
     * @param version - Optional per-product WebSocket streaming version map.
     *   Omitted, or omitted for a product, means that product's latest: futopt
     *   v1.1 (trial-matching frames carrying `isTrial: true` on the trades/books
     *   channels) and stock v1.0. Pass `{ futopt: 'v1.0' }` to stay on futopt
     *   v1.0 and not receive those frames. Only the map form is accepted; a plain
     *   string throws, as does asking for a version a product does not serve
     *   (stock only serves v1.0).
     *
     * @param baseUrl - Optional WebSocket endpoint override, host and path
     *   prefix only (e.g. `wss://express.fugle.tw/marketdata` — no version
     *   segment; it is appended by the SDK). When given it is used
     *   unconditionally. When omitted the endpoint suggested by the token
     *   exchange applies, falling back to the mode's built-in default. `mode`
     *   still governs channel restrictions either way.
     *
     * After this returns, `marketdata.webSocketClient.futopt.url` reports the
     * endpoint that was actually resolved — both the base URL and the version
     * segment come from here, not from anything the caller wrote, so that is
     * the way to confirm which endpoint a client ended up on.
     */
    initRealtime(mode?: Mode, version?: WebSocketVersionOption, baseUrl?: string): void;
    /**
     * add callback to Order
     * @param callback The callback function
     */
    setOnOrder(callback: (err: null | Error, event: OrderResult) => void): void;
    /**
     * add callback to OrderChanged
     * @param callback The callback function
     */
    setOnOrderChanged(callback: (err: null | Error, event: FutOptOrderResult) => void): void;
    /**
     * add callback to FutoptOrder
     * @param callback The callback function
     */
    setOnFutoptOrder(callback: (err: null | Error, event: FutOptOrderResult) => void): void;
    /**
     * add callback to FutoptOrderChanged
     * @param callback The callback function
     */
    setOnFutoptOrderChanged(callback: (err: null | Error, event: FutOptOrderResult) => void): void;
    /**
     * add callback to Event
     * @param callback The callback function
     */
    setOnEvent(callback: (code: string, message: string) => void): void;
}
export { FubonSDK };
