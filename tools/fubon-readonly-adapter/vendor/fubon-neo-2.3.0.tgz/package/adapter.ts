/**
 * Adapter layer for converting Mode enum to WebSocket configuration
 * This preserves backward compatibility while using the parameterized SDK
 */

import { WebSocketClient } from '@fugle/marketdata';
import type { HealthCheckConfig, WebSocketClientOptions, WebSocketVersionOption } from '@fugle/marketdata';

/**
 * Mode enum for backward compatibility
 * Maps to different WebSocket endpoint URLs
 */
export enum Mode {
  Speed = 'speed',
  Normal = 'normal'
}

/**
 * Validate a caller-supplied WebSocket baseUrl.
 *
 * The URL must carry the host and path prefix only (e.g.
 * `wss://express.fugle.tw/marketdata`); fugle-marketdata appends the version
 * segment itself and rejects one written into baseUrl.
 *
 * @param baseUrl - Endpoint override to validate
 * @throws Error if baseUrl is not a ws/wss URL or contains a version segment
 *   such as `/v1.0`
 */
export function validateBaseUrl(baseUrl: string): void {
  if (typeof baseUrl !== 'string' || !/^wss?:\/\//.test(baseUrl)) {
    throw new Error(`baseUrl must be a ws:// or wss:// URL, got: ${baseUrl}`);
  }
  if (/\/v\d+(\.\d+)?(\/|$)/.test(baseUrl)) {
    throw new Error(
      `baseUrl must not contain a version segment (got: ${baseUrl}); ` +
      'pass the host and path prefix only — the version segment is appended by the SDK'
    );
  }
}

/**
 * Build WebSocket configuration from Mode enum
 * Converts legacy Mode-based API to new healthCheck config
 *
 * @param mode - Speed or Normal mode
 * @param sdkToken - SDK authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @param version - Optional per-product streaming version map (e.g.
 *   { futopt: 'v1.0' }). Omitted, or omitted for a product, means that
 *   product's latest — futopt v1.1, stock v1.0. The baseUrl below carries the
 *   host and path prefix only; fugle-marketdata appends the version segment
 *   itself and rejects one written into baseUrl.
 * @param baseUrl - Optional endpoint override. When given it is used as-is;
 *   when omitted the mode's compiled-in default applies (#427 routing passes
 *   the server-suggested endpoint through here).
 * @returns Configuration object for WebSocket client
 */
export function buildWebSocketConfig(
  mode: Mode,
  sdkToken: string,
  fugleRealtime: any,  // FugleRealtime from Rust binding
  version?: WebSocketVersionOption,
  baseUrl?: string
): Partial<WebSocketClientOptions> {
  // Fall back to the compiled-in URL for the mode
  const resolvedBaseUrl = baseUrl ?? (mode === Mode.Speed
    ? fugleRealtime.realtimeWsSpeedUrl
    : fugleRealtime.realtimeWsNormalUrl);

  const config: any = {
    baseUrl: resolvedBaseUrl,  // Use baseUrl instead of url
    sdkToken,
    healthCheck: {
      enabled: true,          // Always enable for Fubon customers
      pingInterval: 30000,    // 30 seconds
      maxMissedPongs: 2       // Disconnect after 2 missed pongs
    } as HealthCheckConfig
  };  // Cast needed since ClientOptions doesn't formally include baseUrl in WebSocketClientOptions

  if (version !== undefined) {
    config.version = version;
  }

  return config;
}

/**
 * Build REST client configuration
 *
 * @param sdkToken - SDK authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for REST client
 */
export function buildRestConfig(sdkToken: string, fugleRealtime: any) {
  return {
    sdkToken,
    // Host and path prefix only — RestClient appends the version segment.
    baseUrl: fugleRealtime.realtimeRestUrl as string,
  };
}

/**
 * Wrap a product client so Speed mode keeps its Fubon-specific channel
 * restrictions.
 *
 * Everything except `subscribe` passes straight through. Listing the members
 * to forward instead would mean re-listing them every time the upstream client
 * grows one, and a missed member is invisible — nothing fails to compile, the
 * caller just gets `undefined`. That is exactly how `url` went missing when
 * fugle-marketdata added it.
 */
function wrapProductClient(client: any, mode: Mode) {
  const wrapped: any = new Proxy(client, {
    get(target, prop, receiver) {
      if (prop === 'subscribe') {
        return (params: { channel: string; [key: string]: any }) => {
          // Speed mode doesn't support 'aggregates' and 'candles' channels
          if (mode === Mode.Speed) {
            if (params.channel === 'aggregates' || params.channel === 'candles') {
              throw new Error(`Speed mode doesn't support ${params.channel} channel`);
            }
          }
          // Same `this` mapping as the general path below: upstream returns
          // nothing today, but it costs a line to not care if that changes.
          const result = target.subscribe(params);
          return result === target ? wrapped : result;
        };
      }

      const value = Reflect.get(target, prop, receiver);
      if (typeof value !== 'function') return value;

      return (...args: any[]) => {
        // Call on the target so 'this' survives the indirection...
        const result = value.apply(target, args);

        // ...but EventEmitter's on/once/off return `this` for chaining, and
        // handing back the bare target would let `client.on(...).subscribe(...)`
        // slip past the check above -- the one thing this wrapper exists to do.
        return result === target ? wrapped : result;
      };
    }
  });

  return wrapped;
}

/**
 * Build WebSocket client with Mode-based configuration and channel validation
 *
 * @param mode - Speed or Normal mode
 * @param sdkToken - SDK authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @param version - Optional per-product streaming version map
 * @param baseUrl - Optional endpoint override (see buildWebSocketConfig)
 * @returns WebSocketClient instance with wrapped stock client for Speed mode validation
 */
export function buildWebSocketClient(
  mode: Mode,
  sdkToken: string,
  fugleRealtime: any,
  version?: WebSocketVersionOption,
  baseUrl?: string
): WebSocketClient {
  const config = buildWebSocketConfig(mode, sdkToken, fugleRealtime, version, baseUrl);
  const client = new WebSocketClient(config as any);

  // Cache wrappers to avoid creating new instances on each access
  let cachedStockWrapper: any = null;
  let cachedFutOptWrapper: any = null;

  // Use Proxy to intercept property access
  return new Proxy(client, {
    get(target, prop, receiver) {
      // Intercept 'stock' property to return wrapped client
      if (prop === 'stock') {
        if (!cachedStockWrapper) {
          cachedStockWrapper = wrapProductClient(target.stock, mode);
        }
        return cachedStockWrapper;
      }

      // Intercept 'futopt' property to return wrapped client
      if (prop === 'futopt') {
        if (!cachedFutOptWrapper) {
          cachedFutOptWrapper = wrapProductClient(target.futopt, mode);
        }
        return cachedFutOptWrapper;
      }

      // For all other properties, return original value
      const value = Reflect.get(target, prop, receiver);

      // If it's a function, bind it to the target to preserve 'this'
      if (typeof value === 'function') {
        return value.bind(target);
      }

      return value;
    }
  }) as WebSocketClient;
}
