/**
 * Adapter layer for converting Mode enum to WebSocket configuration
 * This preserves backward compatibility while using the parameterized SDK
 */
import { WebSocketClient } from '@fugle/marketdata';
import type { WebSocketClientOptions, WebSocketVersionOption } from '@fugle/marketdata';
/**
 * Mode enum for backward compatibility
 * Maps to different WebSocket endpoint URLs
 */
export declare enum Mode {
    Speed = "speed",
    Normal = "normal"
}
/**
 * Validate a caller-supplied WebSocket baseUrl.
 *
 * The URL must carry the host and path prefix only (e.g.
 * `wss://express.fugle.tw/marketdata`); fugle-marketdata appends the version
 * segment itself and rejects one written into baseUrl.
 *
 * @param baseUrl - Endpoint override to validate
 * @throws Error if baseUrl is not a ws/wss URL or contains a version segment
 *   such as `/v1.0`
 */
export declare function validateBaseUrl(baseUrl: string): void;
/**
 * Build WebSocket configuration from Mode enum
 * Converts legacy Mode-based API to new healthCheck config
 *
 * @param mode - Speed or Normal mode
 * @param sdkToken - SDK authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @param version - Optional per-product streaming version map (e.g.
 *   { futopt: 'v1.0' }). Omitted, or omitted for a product, means that
 *   product's latest — futopt v1.1, stock v1.0. The baseUrl below carries the
 *   host and path prefix only; fugle-marketdata appends the version segment
 *   itself and rejects one written into baseUrl.
 * @param baseUrl - Optional endpoint override. When given it is used as-is;
 *   when omitted the mode's compiled-in default applies (#427 routing passes
 *   the server-suggested endpoint through here).
 * @returns Configuration object for WebSocket client
 */
export declare function buildWebSocketConfig(mode: Mode, sdkToken: string, fugleRealtime: any, // FugleRealtime from Rust binding
version?: WebSocketVersionOption, baseUrl?: string): Partial<WebSocketClientOptions>;
/**
 * Build REST client configuration
 *
 * @param sdkToken - SDK authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for REST client
 */
export declare function buildRestConfig(sdkToken: string, fugleRealtime: any): {
    sdkToken: string;
    baseUrl: string;
};
/**
 * Build WebSocket client with Mode-based configuration and channel validation
 *
 * @param mode - Speed or Normal mode
 * @param sdkToken - SDK authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @param version - Optional per-product streaming version map
 * @param baseUrl - Optional endpoint override (see buildWebSocketConfig)
 * @returns WebSocketClient instance with wrapped stock client for Speed mode validation
 */
export declare function buildWebSocketClient(mode: Mode, sdkToken: string, fugleRealtime: any, version?: WebSocketVersionOption, baseUrl?: string): WebSocketClient;
