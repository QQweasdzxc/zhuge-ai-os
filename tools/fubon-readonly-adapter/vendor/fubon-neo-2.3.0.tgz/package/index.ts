// Re-export all types and values from trade.js
export * from './trade.js';

// Import what we need for FubonSDK implementation
import { CoreSdk, FugleRealtime } from './trade.js';
import { RestClient, WebSocketClient } from '@fugle/marketdata';
import type { WebSocketVersionOption } from '@fugle/marketdata';
import { Mode, buildWebSocketClient, buildRestConfig, validateBaseUrl } from './adapter.js';
import type { FutOptOrderResult, OrderResult } from './trade.js';

// Re-export Mode for external use
export { Mode };

// Re-export fugle-marketdata streaming version / futopt message types
export type {
  WebSocketVersionOption,
  WebSocketVersionMap,
  WebSocketFutOptTrade,
  WebSocketFutOptTradesData,
  WebSocketFutOptBooksData,
  WebSocketFutOptAggregatesData,
  WebSocketFutOptMessage,
} from '@fugle/marketdata';

import * as packageJson from "./package.json";
const version = packageJson.version;

class FubonSDK extends CoreSdk {
  marketdata: {
    webSocketClient: WebSocketClient;
    restClient: RestClient;
  };

  /**
   * constructor of FubonSDK
   * @param pongInteval
   * @param missedCount
   * @param url The first value
   */
  constructor(
    pongInteval?: number | null,
    missedCount?: number | null,
    url?: string | null
  ) {
    super(version, pongInteval as any, missedCount as any, url);
    global.__fubon_sdk_ref__ = this;
  }

  /**
   * Initial market data and get authorised
   * @param mode - Speed or Normal mode (defaults to Speed)
   * @param version - Optional per-product WebSocket streaming version map.
   *   Omitted, or omitted for a product, means that product's latest: futopt
   *   v1.1 (trial-matching frames carrying `isTrial: true` on the trades/books
   *   channels) and stock v1.0. Pass `{ futopt: 'v1.0' }` to stay on futopt
   *   v1.0 and not receive those frames. Only the map form is accepted; a plain
   *   string throws, as does asking for a version a product does not serve
   *   (stock only serves v1.0).
   *
   * @param baseUrl - Optional WebSocket endpoint override, host and path
   *   prefix only (e.g. `wss://express.fugle.tw/marketdata` — no version
   *   segment; it is appended by the SDK). When given it is used
   *   unconditionally. When omitted the endpoint suggested by the token
   *   exchange applies, falling back to the mode's built-in default. `mode`
   *   still governs channel restrictions either way.
   *
   * After this returns, `marketdata.webSocketClient.futopt.url` reports the
   * endpoint that was actually resolved — both the base URL and the version
   * segment come from here, not from anything the caller wrote, so that is
   * the way to confirm which endpoint a client ended up on.
   */
  initRealtime(mode = Mode.Speed, version?: WebSocketVersionOption, baseUrl?: string) {
    // Reject caller input before performing the authenticated token exchange.
    if (baseUrl !== undefined) validateBaseUrl(baseUrl);

    const sdkToken = super.exchangeRealtimeToken();
    const wsBaseUrl = baseUrl ?? super.realtimeWsUrl(mode);

    // Use adapter to build WebSocket client with channel validation
    const fugleRealtime = new FugleRealtime();
    const restConfig = buildRestConfig(sdkToken, fugleRealtime);

    this.marketdata = {
      webSocketClient: buildWebSocketClient(mode, sdkToken, fugleRealtime, version, wsBaseUrl),
      restClient: new RestClient(restConfig),
    };
  }

  /**
   * add callback to Order
   * @param callback The callback function
   */
  setOnOrder(callback: (err: null | Error, event: OrderResult) => void) {
    super.innerSetOnOrder(function (_err: any, event: any) {
      if (event.isSuccess) {
        callback(null, event.data);
      } else {
        callback(new Error(event.message), event.data);
      }
    });
  }

  /**
   * add callback to OrderChanged
   * @param callback The callback function
   */
  setOnOrderChanged(
    callback: (err: null | Error, event: FutOptOrderResult) => void
  ) {
    super.innerSetOnOrderChanged(function (_err: any, event: any) {
      if (event.isSuccess) {
        callback(null, event.data);
      } else {
        callback(new Error(event.message), event.data);
      }
    });
  }

  /**
   * add callback to FutoptOrder
   * @param callback The callback function
   */
  setOnFutoptOrder(
    callback: (err: null | Error, event: FutOptOrderResult) => void
  ) {
    super.innerSetOnFutoptOrder(function (_err: any, event: any) {
      if (event.isSuccess) {
        callback(null, event.data);
      } else {
        callback(new Error(event.message), event.data);
      }
    });
  }

  /**
   * add callback to FutoptOrderChanged
   * @param callback The callback function
   */
  setOnFutoptOrderChanged(
    callback: (err: null | Error, event: FutOptOrderResult) => void
  ) {
    super.innerSetOnFutoptOrderChanged(function (_err: any, event: any) {
      if (event.isSuccess) {
        callback(null, event.data);
      } else {
        callback(new Error(event.message), event.data);
      }
    });
  }

  /**
   * add callback to Event
   * @param callback The callback function
   */
  setOnEvent(callback: (code: string, message: string) => void) {
    super.innerSetOnEvent(function (_err: any, event: [string, string]) {
      let [code, message] = event;
      callback(code, message);
    });
  }
}

// Export our custom SDK class
export { FubonSDK };
